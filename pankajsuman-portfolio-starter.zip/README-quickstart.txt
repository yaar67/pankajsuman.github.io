Quickstart for www.pankajsuman.com (GitHub Pages)

1) Create a GitHub repo named: pankajsuman.github.io
2) Upload *all files* from this folder (index.html, photos/*, CNAME).
3) In the repo, go to Settings → Pages. Source = main branch, /(root). Save.
4) In your domain DNS:
   - CNAME (host: www) → pankajsuman.github.io
   - Optional: A records for @ → 185.199.108.153, 185.199.109.153, 185.199.110.153, 185.199.111.153
5) Back in Settings → Pages, set Custom domain = www.pankajsuman.com and enable HTTPS.
6) Replace photos in /photos with your own images; update captions or add more <figure> tiles.

Tip: export images to ~1800px on the long edge for fast loading.